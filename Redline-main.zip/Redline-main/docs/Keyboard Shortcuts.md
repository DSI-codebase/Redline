---
tags: [reference, basics]
---

# Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl+O` | Open PDF (or **drag a PDF** onto the window) |
| `Ctrl+S` | Save markup (`.marked.pdf` + sidecar) |
| `Ctrl+Shift+S` | Save As… (fork to a new working file) |
| `Ctrl+Shift+E` | Export annotated PDF… |
| `Ctrl+P` | Print the drawing (with marks) via the system print dialog |
| `Ctrl+1` … `Ctrl+0` | Pick a tool (Select, Highlight, Pen, Eraser, Comment, Text box, Callout, Rectangle, Arrow, Cloud) |
| `Ctrl+F` | Find in document (search panel with options + match list; `Enter` / `Shift+Enter` to step, `Esc` inside it to close) |
| `F3` / `Shift+F3` | Next / previous search match |
| `Ctrl+C` | Copy the selected mark(s) — or, with no mark selected, the selected text |
| `Ctrl+V` | Paste the copied mark(s) onto the current page |
| `Ctrl+Z` | Undo |
| `Ctrl+Shift+Z` | Redo |
| `Ctrl` + scroll | Zoom in / out |
| `Ctrl` `+` / `Ctrl` `-` | Zoom in / out |
| **Space** + drag | Pan |
| Middle-drag | Pan |
| `F8` | Toggle the **Reference viewer** (read-only second view of the same PDF) |
| `F9` | Toggle the left **Navigation** pane |
| `F10` | Toggle the right **Comments** pane |
| `Esc` | Cancel an in-progress mark / clear a text selection (the search panel closes only from `Esc` inside it) |
| `Ctrl+Enter` / `Shift+Enter` | Save the comment / text-box editor (same as **OK**) |
| `Ctrl` + wheel (Graph) | Zoom the [[Home]] manual's graph view |
| `Delete` | Delete the selected mark / comment (always asks to confirm) |

See [[Viewer]] and [[Markup Tools]] for the full interaction model.

#reference
